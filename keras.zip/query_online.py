# -*- coding: utf-8 -*-
# Author: yongyuan.name

import numpy as np
from numpy import genfromtxt
import h5py

h5f = h5py.File('featsCNN.h5','r')
feats = h5f['dataset_1'][:]
imgNames = h5f['dataset_2'][:]
h5f.close()


queryVec = genfromtxt("feats.csv",delimiter=',')
scores = np.dot(queryVec, feats.T)

rank_ID = np.argsort(scores)[::-1]
rank_score = scores[rank_ID][0:10]
print rank_score

maxres = 10
imlist = [imgNames[index] for i,index in enumerate(rank_ID[0:maxres])]
print imlist
