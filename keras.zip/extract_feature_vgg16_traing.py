#KERAS
from keras.applications.vgg16 import VGG16
from keras.preprocessing import image
from keras.applications.vgg16 import preprocess_input
from keras.layers import Input, Flatten, Dense
from keras.models import Model
from keras.models import Sequential
from keras.models import load_model
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.optimizers import SGD,RMSprop,adam
from keras.utils import np_utils
from keras.regularizers import l1,l2

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import os
import theano
from PIL import Image
from numpy import *
# SKLEARN
from sklearn.utils import shuffle
from sklearn.cross_validation import train_test_split



path1 = '/home/lab1007/flask-keras-cnn-image-retrieval/database'    #path of folder of images    
path2 = '/home/lab1007/flask-keras-cnn-image-retrieval/database_save'  #path of folder to save images 
#preprocessing image
def preprocessing():
	#resize data
	img_rows, img_cols = 200, 200  

	listing = os.listdir(path1)
	num_samples=size(listing)
	print num_samples

	for file in listing:
	    im = Image.open(path1 + '/' + file)  
	    img = im.resize((img_rows,img_cols))
	    img.save(path2 +'/' +  file)
	    #transform to grey image
	    #gray = img.convert('L')          
	    #gray.save(path2 +'/' +  file)

	imlist = os.listdir(path2)

	im1 = array(Image.open(path2 + '/'+ imlist[0])) # open one image to get size
	m,n = im1.shape[0:2] # get the size of the images
	imnbr = len(imlist) # get the number of images
	print imnbr

######################################################################################################
# create matrix to store all flattened images
def pretrained_model():
	imlist = os.listdir(path2)
	immatrix = array([array(Image.open(path2+ '/' + im2))
    	          for im2 in imlist],'f')
	num_samples=size(imlist)               
	
	label=np.ones((num_samples,),dtype = int)
	#assign label
	label[0:37]=0
	label[38:112]=1 #0~75
	label[113:152]=2 #0~38
	label[152:173]=3 #0~22
	label[174:233]=4 #0~65


	data,Label = shuffle(immatrix,label, random_state=2)
	train_data = [data,Label]

	print (train_data[0].shape)
	print (train_data[1].shape)

	#Get back the convolutional part of a VGG network trained on ImageNet
	model_vgg16_conv = VGG16(weights='imagenet', include_top=False)
	model_vgg16_conv.summary()

	#Create your own input format (here 3x200x200)
	input = Input(shape=(200,200,3),name = 'image_input')

	#Use the generated model 
	output_vgg16_conv = model_vgg16_conv(input)

	#Add the fully-connected layers 	
	x = Flatten(name='flatten')(output_vgg16_conv)
	x = Dense(300, activation='softplus',W_regularizer=l2(0.01), name='fc1')(x)
	x = Dense(200, activation='softplus', name='fc2')(x)
	x = Dense(5, activation='softmax', name='predictions')(x)

	#Create your own model 
	my_model = Model(input=input, output=x)

	#In the summary, weights and layers from VGG part will be hidden, but they will be fit during the training
	my_model.summary()

	#loading the data
	(X, y) = (train_data[0],train_data[1])


	X,X_test,y,y_test=train_test_split(X,y,test_size=0.3,random_state=10)

	#Then training with your data ! 
	my_model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
	# Fit the model
	my_model.fit(X, y,validation_data=(X_test,y_test), epochs=2, batch_size=1,shuffle=True)

	my_model.save('vgg16_final2.h5')

	# evaluate the model
	scores = my_model.evaluate(X, y)
	print("\n%s: %.2f%%" % (my_model.metrics_names[1], scores[1]*100))
	

def pred():
	imlist = os.listdir(path2)
	immatrix = array([array(Image.open(path2+ '/' + im2))
    	          for im2 in imlist],'f')
	num_samples=size(imlist)               
	label=np.ones((num_samples,),dtype = int)
	label[0:37]=0
	label[38:112]=1 #0~75
	label[113:152]=2 #0~38
	label[152:173]=3 #0~22
	label[174:233]=4 #0~65


	data,Label = shuffle(immatrix,label, random_state=2)
	train_data = [data,Label]
	(X, y) = (train_data[0],train_data[1])
	print (train_data[0].shape)
	model = load_model('vgg16_final2.h5')

	y_pred = model.predict(X[0:4,:])
	print y_pred


preprocessing()
pretrained_model()
pred()

